Chess-Network
=============
Online multiplayer chess [BETA]

Installation - 
	You can run the app with nodejs and your own local server(You need installed Apache, Nginx etc...). Place the main directory of the project in    the localhost folder of your server.
	Then in the console go to /server folder of the project and start the server with "node server.js".
	Once the server is running you can open the app in the browser - "http://localhost/your_folder"
